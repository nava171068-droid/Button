package com.example.floatbutton

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.abs

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private var buttonView: ImageView? = null
    private var player: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        addFloatingButton()
    }

    private fun startAsForeground() {
        val channelId = "float_button"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Floating button", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("ปุ่มลอยกำลังทำงาน")
            .setContentText("แตะปุ่มลอยเพื่อเล่น/หยุดเพลง")
            .setSmallIcon(R.drawable.button)
            .build()
        startForeground(1, notification)
    }

    private fun addFloatingButton() {
        val size = (64 * resources.displayMetrics.density).toInt()

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        val view = ImageView(this).apply {
            setImageResource(R.drawable.btn_selector)
            scaleType = ImageView.ScaleType.FIT_XY
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = 8 * resources.displayMetrics.density

        view.setOnTouchListener { v: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    v.isPressed = true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        windowManager.updateViewLayout(v, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    if (!moved) toggleMusic()
                }
                MotionEvent.ACTION_CANCEL -> v.isPressed = false
            }
            true
        }

        windowManager.addView(view, params)
        buttonView = view
    }

    private fun toggleMusic() {
        if (player == null) {
            player = MediaPlayer.create(this, R.raw.music)?.apply { isLooping = true }
        }
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.start()
    }

    override fun onDestroy() {
        buttonView?.let { windowManager.removeView(it) }
        buttonView = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
