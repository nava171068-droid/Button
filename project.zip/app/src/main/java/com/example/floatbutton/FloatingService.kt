package com.example.floatbutton

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max

class FloatingService : Service() {

    private val channelId = "float_button"
    private val model = "claude-haiku-5-5"   // เปลี่ยนรุ่นได้ เช่น claude-sonnet-5-5 (ฉลาดกว่า แต่ช้า/แพงกว่า)
    private val groqModel = "qwen/qwen3.6-27b"   // โมเดล vision ของ Groq ตามเอกสารล่าสุด (ชื่ออาจเปลี่ยน)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private var buttonView: ImageView? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var screenW = 0
    private var screenH = 0
    private var capW = 0
    private var capH = 0

    @Volatile private var running = false
    private var worker: Thread? = null
    private val history = ArrayList<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Floating AI", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, channelId)
            .setContentTitle("ปุ่มลอย AI")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.button)
            .build()

    private fun status(text: String) {
        Log.d("FloatAI", text)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, notification(text))
    }

    private fun toast(s: String) = ui.post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY

        val n = notification("แตะปุ่มลอยเพื่อเริ่ม/หยุดบอท")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }

        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopBot()
                stopSelf()
            }
        }, ui)
        projection = p
        addFloatingButton()
        return START_NOT_STICKY
    }

    // ---------- ปุ่มลอย ----------
    private fun addFloatingButton() {
        val size = (64 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }
        val view = ImageView(this).apply {
            setImageResource(R.drawable.btn_selector)
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = 0.6f
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = 8 * resources.displayMetrics.density

        view.setOnTouchListener { v: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    v.isPressed = true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        wm.updateViewLayout(v, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    if (!moved) toggleBot()
                }
                MotionEvent.ACTION_CANCEL -> v.isPressed = false
            }
            true
        }
        wm.addView(view, params)
        buttonView = view
    }

    // ---------- จับภาพหน้าจอ ----------
    private fun ensureCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        if (display != null && dm.widthPixels == screenW && dm.heightPixels == screenH) return

        screenW = dm.widthPixels
        screenH = dm.heightPixels
        val scale = 1024f / max(screenW, screenH)
        capW = (screenW * scale).toInt()
        capH = (screenH * scale).toInt()

        val newReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        val d = display
        if (d == null) {
            display = projection!!.createVirtualDisplay(
                "cap", capW, capH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            d.resize(capW, capH, dm.densityDpi)
            d.surface = newReader.surface
        }
        reader?.close()
        reader = newReader
    }

    private fun captureBase64(): String? {
        ensureCapture()
        val r = reader ?: return null
        var image: Image? = null
        for (i in 0 until 20) {
            image = r.acquireLatestImage()
            if (image != null) break
            Thread.sleep(100)
        }
        val img = image ?: return null
        try {
            val plane = img.planes[0]
            val pad = (plane.rowStride - plane.pixelStride * capW) / plane.pixelStride
            val full = Bitmap.createBitmap(capW + pad, capH, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, capW, capH)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            img.close()
        }
    }

    private val systemPrompt = """
You are an AI playing Minecraft (Bedrock, touch controls) on an Android phone by looking at screenshots.
Typical touch controls: a virtual joystick at bottom-left (drag from its center toward a direction to walk),
dragging on the right/center area of the screen turns the camera, a jump button at bottom-right,
hold a finger on the block at the crosshair (screen center) to break it, tap to place a block or attack.
Look at the screenshot to find the real positions of controls.
Reply with ONLY a JSON object, no markdown:
{"thought":"short reasoning","actions":[...]}
Allowed actions (coordinates are pixels in the screenshot):
{"type":"tap","x":0,"y":0}
{"type":"hold","x":0,"y":0,"ms":1500}
{"type":"swipe","x1":0,"y1":0,"x2":0,"y2":0,"ms":600}
{"type":"wait","ms":800}
Use at most 4 actions per reply. Prefer small, safe movements. If a menu or dialog is open, close it first.
""".trimIndent()

    private fun userPrompt(goal: String): String =
        "Goal: $goal\nScreenshot size: ${capW}x${capH}\n" +
            "Your recent steps:\n${history.joinToString("\n")}\nWhat should I do next?"

    // ---------- เรียก Groq (OpenAI-compatible) ----------
    private fun askGroq(b64: String, goal: String, apiKey: String): String {
        val text = systemPrompt + "\n\n" + userPrompt(goal)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(
                JSONObject().put("type", "image_url").put(
                    "image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")
                )
            )
        val body = JSONObject()
            .put("model", groqModel)
            .put("max_tokens", 1000)
            .put("temperature", 0.3)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("API $code: ${resp.take(200)}")

        val reply = JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content")
        return Regex("<think>[\\s\\S]*?</think>").replace(reply, "")
    }

    // ---------- เรียก Claude ----------
    private fun askClaude(b64: String, goal: String, apiKey: String): String {
        val system = systemPrompt

        val userText = userPrompt(goal)

        val content = JSONArray()
            .put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
                )
            )
            .put(JSONObject().put("type", "text").put("text", userText))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 600)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("API $code: ${text.take(200)}")

        val arr = JSONObject(text).getJSONArray("content")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") return o.getString("text")
        }
        throw RuntimeException("ไม่มีข้อความตอบกลับ")
    }

    // ---------- สั่งกด ----------
    private fun num(a: JSONObject, k: String): Float = a.optDouble(k, -1.0).toFloat()

    private fun runActions(acts: JSONArray?, svc: GameAccessibilityService) {
        if (acts == null) return
        val sx = screenW.toFloat() / capW
        val sy = screenH.toFloat() / capH
        val maxX = (screenW - 1).toFloat()
        val maxY = (screenH - 1).toFloat()
        for (i in 0 until minOf(acts.length(), 4)) {
            if (!running) return
            val a = acts.getJSONObject(i)
            when (a.optString("type")) {
                "tap", "hold" -> {
                    val x = num(a, "x"); val y = num(a, "y")
                    if (x < 0 || y < 0) continue
                    val ms = if (a.optString("type") == "tap") 60L
                    else a.optInt("ms", 1000).coerceIn(100, 5000).toLong()
                    val px = (x * sx).coerceIn(0f, maxX)
                    val py = (y * sy).coerceIn(0f, maxY)
                    svc.gesture(px, py, px, py, ms)
                }
                "swipe" -> {
                    val x1 = num(a, "x1"); val y1 = num(a, "y1")
                    val x2 = num(a, "x2"); val y2 = num(a, "y2")
                    if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) continue
                    svc.gesture(
                        (x1 * sx).coerceIn(0f, maxX), (y1 * sy).coerceIn(0f, maxY),
                        (x2 * sx).coerceIn(0f, maxX), (y2 * sy).coerceIn(0f, maxY),
                        a.optInt("ms", 600).coerceIn(100, 3000).toLong()
                    )
                }
                "wait" -> Thread.sleep(a.optInt("ms", 1000).coerceIn(200, 3000).toLong())
            }
        }
    }

    // ---------- วงจรบอท ----------
    private fun toggleBot() = if (running) stopBot() else startBot()

    private fun startBot() {
        val svc = GameAccessibilityService.instance
        if (svc == null) {
            toast("Accessibility ถูกปิดอยู่ กรุณาเปิดใหม่")
            return
        }
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val key = prefs.getString("api_key", "") ?: ""
        val goal = prefs.getString("goal", "") ?: ""
        if (key.isBlank()) {
            toast("ยังไม่ได้ใส่ API key")
            return
        }
        running = true
        history.clear()
        buttonView?.alpha = 1f
        status("บอทเริ่มทำงาน: $goal")

        worker = Thread {
            while (running) {
                try {
                    val b64 = captureBase64()
                    if (b64 == null) {
                        status("จับภาพไม่ได้ ลองใหม่...")
                        Thread.sleep(1000)
                        continue
                    }
                    val reply = if (key.startsWith("gsk_")) askGroq(b64, goal, key) else askClaude(b64, goal, key)
                    val s = reply.indexOf('{')
                    val e = reply.lastIndexOf('}')
                    if (s < 0 || e <= s) {
                        status("ตอบผิดรูปแบบ: ${reply.take(80)}")
                        continue
                    }
                    val obj = JSONObject(reply.substring(s, e + 1))
                    val thought = obj.optString("thought")
                    status(thought)
                    history.add(thought)
                    if (history.size > 6) history.removeAt(0)
                    runActions(obj.optJSONArray("actions"), svc)
                    Thread.sleep(400)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    val msg = e.message ?: e.toString()
                    status("ผิดพลาด: $msg")
                    if (msg.startsWith("API 401")) {
                        toast("API key ไม่ถูกต้อง")
                        stopBot()
                        break
                    }
                    try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
                }
            }
        }.also { it.start() }
    }

    private fun stopBot() {
        running = false
        worker?.interrupt()
        worker = null
        ui.post { buttonView?.alpha = 0.6f }
        status("บอทหยุดแล้ว แตะปุ่มเพื่อเริ่มใหม่")
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        buttonView?.let { wm.removeView(it) }
        buttonView = null
        display?.release()
        reader?.close()
        val p = projection
        projection = null
        p?.stop()
        super.onDestroy()
    }
}
