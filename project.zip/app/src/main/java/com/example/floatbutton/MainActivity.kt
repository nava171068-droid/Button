package com.example.floatbutton

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "ปุ่มลอย: แตะ = เล่น/หยุดเพลง, ลาก = ย้ายตำแหน่ง"
            textSize = 16f
            gravity = Gravity.CENTER
        })

        root.addView(Button(this).apply {
            text = "1) อนุญาตแสดงทับแอปอื่น"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        root.addView(Button(this).apply {
            text = "2) เริ่มปุ่มลอย"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(context, "ยังไม่ได้อนุญาตแสดงทับแอปอื่น", Toast.LENGTH_LONG).show()
                } else {
                    startForegroundService(Intent(context, FloatingService::class.java))
                }
            }
        })

        root.addView(Button(this).apply {
            text = "หยุดปุ่มลอย"
            setOnClickListener { stopService(Intent(context, FloatingService::class.java)) }
        })

        setContentView(root)
    }
}
