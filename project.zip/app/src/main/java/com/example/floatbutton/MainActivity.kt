package com.example.floatbutton

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var keyInput: EditText
    private lateinit var goalInput: EditText
    private val reqCapture = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "AI เล่นเกม: แตะปุ่มลอย = เริ่ม/หยุดบอท, ลาก = ย้ายปุ่ม"
            textSize = 16f
            gravity = Gravity.CENTER
        })

        keyInput = EditText(this).apply {
            hint = "API key (Anthropic sk-ant-... หรือ Groq gsk_...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        root.addView(keyInput)

        goalInput = EditText(this).apply {
            hint = "เป้าหมายของ AI"
            setText(prefs.getString("goal", "Punch a tree to collect wood"))
        }
        root.addView(goalInput)

        root.addView(Button(this).apply {
            text = "1) อนุญาตแสดงทับแอปอื่น"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        root.addView(Button(this).apply {
            text = "2) เปิด Accessibility (Float Button AI)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "3) เริ่มปุ่มลอย + อนุญาตจับภาพหน้าจอ"
            setOnClickListener { start(prefs) }
        })

        root.addView(Button(this).apply {
            text = "หยุดทั้งหมด"
            setOnClickListener { stopService(Intent(context, FloatingService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun start(prefs: android.content.SharedPreferences) {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("ใส่ API key ก่อน")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("ยังไม่ได้อนุญาตแสดงทับแอปอื่น")
            return
        }
        if (GameAccessibilityService.instance == null) {
            toast("ยังไม่ได้เปิด Accessibility")
            return
        }
        prefs.edit()
            .putString("api_key", key)
            .putString("goal", goalInput.text.toString().trim())
            .apply()
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, FloatingService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            toast("ปุ่มลอยพร้อมแล้ว เปิดเกมแล้วแตะปุ่มเพื่อเริ่ม")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
